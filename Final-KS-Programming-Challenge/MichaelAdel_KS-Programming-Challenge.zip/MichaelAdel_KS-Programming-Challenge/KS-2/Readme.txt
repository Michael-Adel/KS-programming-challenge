Note: These files are made to be built on Linux 


========================
BUILDING THE FILE STEPS:
========================

1) Open the Terminal and go to the directory where you have the files

2) write the command: make

3) Then write the command: ./Source

you will have to enter your first name and last name . The name of the file you want to open in this directory ( or the full path if it is found in another directory). you will be asked for the number of questions you want to be asked. Remember that the included file contains only 3 questions. 

4) After finishing you can type : 'make clean' to make everything return as it was 
