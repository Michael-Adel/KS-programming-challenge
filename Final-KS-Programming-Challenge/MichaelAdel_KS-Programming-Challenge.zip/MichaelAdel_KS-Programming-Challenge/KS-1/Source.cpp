#include "printConsole.h"

int main()
{
	PRINT("hello from the source code ");
}
