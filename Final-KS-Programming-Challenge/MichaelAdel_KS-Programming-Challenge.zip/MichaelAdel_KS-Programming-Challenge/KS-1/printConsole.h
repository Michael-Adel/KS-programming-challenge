#ifndef PRINTCON_H
#define PRINTCON_H
#ifndef PLATFORM  
#define PLATFORM 0
#endif
#include "printAPI.h"
#endif
