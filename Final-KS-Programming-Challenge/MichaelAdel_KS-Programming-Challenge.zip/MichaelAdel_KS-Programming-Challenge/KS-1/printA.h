#ifndef PRINTA_H
#define PRINTA_H

#include <iostream>
#include <string>

void printA(std::string out) {
	std::cout << out << std::endl;
}


#endif

